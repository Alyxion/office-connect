# office-connect

Unofficial MCP server for Microsoft Office integration — powered by Microsoft Graph (msgraph-sdk).

> This package is under active development. A full release is coming soon.
