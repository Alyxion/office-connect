"""office-connect — Unofficial MCP server for Microsoft Office integration via Microsoft Graph."""

__version__ = "0.1.0"
